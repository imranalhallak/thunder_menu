<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Http\Requests\StoreBranchRequest;
use App\Http\Requests\UpdateBranchRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class BranchController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreBranchRequest $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'logo' => 'nullable|image|max:2048', // Validate logo file
        ]);

        // Generate a base slug
        $baseSlug = Str::slug($validatedData['name']);

        // Ensure slug uniqueness by appending a number
        $slug = $baseSlug;
        $count = 1;
        while (Branch::where('slug', $slug)->exists()) {
            $slug = $baseSlug . '' . $count;
            $count++;
        }

        // Initialize the branch with the user ID
        $branch = Branch::create([
            'name' => $validatedData['name'],
            'slug' => $slug,
            'user_id' => auth()->id(),
            'logo' => null, // Initialize logo as null
        ]);

        // Handle the logo upload if present
        if ($request->hasFile('logo')) {
            $path = $request->file('logo')->store('branch_logos', 'public');
            $branch->logo = $path;
            $branch->save();
        }

        return redirect()->route('menus.index')
            ->with('success', 'Branch created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Branch $branch)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Branch $branch)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateBranchRequest $request, Branch $branch)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Branch $branch)
    {
        //
    }

    /**
     * Set the default branch for the authenticated user.
     */
    public function setBranch(Request $request)
    {
        $request->validate([
            'branch_id' => 'required|exists:branches,id',
        ]);

        $user = auth()->user();
        $user->default_branch = $request->branch_id;
        $user->save();

        return redirect('dashboard')->with('success', 'Default branch updated.');
    }
}
