<?php

namespace App\Enums;

enum Mode: string
{
    case LIGHT = 'light';
    case DARK = 'dark';
}
